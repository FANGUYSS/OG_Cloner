import requests
import threading
import asyncio
import base64
from pystyle import *
import random
from datetime import datetime
import os
import time

def logo():
    ascii_logo = r"""
     ___   ____    ____ _                       
  / _ \ / ___|  / ___| | ___  _ __   ___ _ __ 
 | | | | |  _  | |   | |/ _ \| '_ \ / _ \ '__|
 | |_| | |_| | | |___| | (_) | | | |  __/ |   
  \___/ \____|  \____|_|\___/|_| |_|\___|_|   
                                              
    """

    branding = r"""
  Made Using 🧠 And 💖 By FANGUYSS | Discord ID: fanguyss.
    """

    # Gradient colored output
    print(Colorate.Horizontal(Colors.purple_to_blue, ascii_logo))
    print(Colorate.Vertical(Colors.red_to_yellow, branding))

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def current_time():
    return datetime.now().strftime("%H:%M:%S")

# Color shortcuts
b = Colors.dark_blue
r = Colors.red
g = Colors.green
y = Colors.yellow
w = Colors.white